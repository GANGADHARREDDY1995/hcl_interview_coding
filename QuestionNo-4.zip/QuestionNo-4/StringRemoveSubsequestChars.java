package java8DataAndTimeApi;
public class StringRemoveSubsequestChars {

static boolean isCompleted = false;

public static void main(String[] args) {
// Program designed for message should be only alphabetics

String message="abccddd";

System.out.println("Original message : "+message);
do {
message = shortString(message);
} while(!isCompleted);

System.out.println("Message after processed : "+message);

}

public static String shortString(String message) {

isCompleted = true;

if(message==null ||  message.isEmpty() ) {
return "";
}

int len = message.length();
char[] messageCharArray = message.toCharArray();
for (int i=0;i< len-1;i++) {
if ((len >= i+1) && messageCharArray[i] == messageCharArray[i+1]) {
if((len > i+2) && messageCharArray[i+1] == messageCharArray[i+2]) {
i = replacewithZero(messageCharArray,i+1,messageCharArray[i]);
} else {
messageCharArray[i]='0';
messageCharArray[i+1]='0';
isCompleted = false;
}

}
}
String processedMessage = new String(messageCharArray);
message=processedMessage.replace("0","");
System.out.println("Message : "+message);
return message;
}

// remove chars in case of more than twice
static private int replacewithZero(char[] messageCharArray,int startIndex,char searchChar) {
for(int i = startIndex;i<messageCharArray.length;i++) {
if(messageCharArray[i] == searchChar) {
messageCharArray[i]='0';
isCompleted = false;
} else {
startIndex=i-1;
break;
}
}
return startIndex;
}

}