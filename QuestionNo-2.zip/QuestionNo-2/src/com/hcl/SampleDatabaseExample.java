package com.hcl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SampleDatabaseExample {
	static Connection connection = null;
	static PreparedStatement statement = null;
	
	static String createQuerry = "CREATE TABLE STORING_FILE_INFO" + "( Result_Time timestamp NULL, "
			+ " Granularity_Period  varchar(200)  NULL, " + " Object_Name varchar(200)  NULL, "
			+ " Cell_ID int NULL, Call_Attemps int NULL)";

	static String insertQuerry = "insert into STORING_FILE_INFO(Result_Time, Granularity_Period, Object_Name,"
			+ "Cell_ID, Call_Attemps) values (?,?,?,?,?)";

	static String path = "D:\\Workspace\\Files";

	public static void main(String[] args) throws ParseException {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("jdbc class is loaded ");
			connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/school_database", "postgres",
					"admin");
			System.out.println("jdbc connection is loaded ");

			Statement deleteStatement = connection.createStatement();
			deleteStatement.execute("drop table STORING_FILE_INFO");
			System.out.println("Table STORING_FILE_INFO is deleted..");

			Statement createStatement = connection.createStatement();
			createStatement.execute(createQuerry);
			System.out.println("Table STORING_FILE_INFO is created..");

			statement = connection.prepareStatement(insertQuerry);

			List<FileEntity> list = readingDataFromFiles(path);
			int count = 0;
			for (FileEntity entity : list) {
				statement.setDate(1, new java.sql.Date(entity.getResultTime().getTime()));
				statement.setInt(2, entity.getGranularityPeriod());
				statement.setString(3, entity.getObjectName());
				statement.setInt(4, entity.getCellsId());
				statement.setInt(5, entity.getCellAttempt());
				count++;
				int recordCount = statement.executeUpdate();
				count += recordCount;
			}
			System.out.println("Inserted record successfully : " + count);

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading class: " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception  : " + e.getMessage());
		} finally {
			try {
				statement.close();
				System.out.println("statement closing ");
				connection.close();
				System.out.println("connection closing ");
			} catch (SQLException e) {
				System.out.println("closing connection exception : " + e.getMessage());
			}
		}
	}

	static List<FileEntity> readingDataFromFiles(String path) throws ParseException {
		BufferedReader bufferedReader = null;
		List<FileEntity> allContent = new ArrayList<FileEntity>();
		File dir = new File(path);
		File[] multipleFiles = dir.listFiles();
		for (File file : multipleFiles) {
			try {
				bufferedReader = new BufferedReader(new FileReader(file));
				System.out.println(file.getName() + " is loaded to read content..");
				String values;
				while ((values = bufferedReader.readLine()) != null) {
					String[] fieldData = values.split(",");

					FileEntity fileEntity = new FileEntity();
					fileEntity.setResultTime(convertStringToDate(fieldData[0]));
					fileEntity.setGranularityPeriod(parseToInt(fieldData[1]));
					fileEntity.setObjectName(trimInputField(fieldData[2]));
					fileEntity.setCellsId(parseToInt(fieldData[3]));
					fileEntity.setCellAttempt(parseToInt(fieldData[4]));
					
					allContent.add(fileEntity);
				}
			} catch (FileNotFoundException e) {
				System.out.println("file not found exception : " + e.getMessage());
			} catch (IOException e) {
				System.out.println("exception : " + e.getMessage());
			} finally {
				try {
					bufferedReader.close();
				} catch (IOException e) {
					System.out.println("bufered reader  exception : " + e.getMessage());
				}
			}
		}
		return allContent;
	}

	private static Date convertStringToDate(final String date) throws ParseException {
		if (date != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD HH:mm");
			return dateFormat.parse(date.trim());
		}
		return null;
	}

	private static String trimInputField(final String field) {
		return field != null ? field.trim() : null;
	}

	private static Integer parseToInt(final String field) {
		return field != null ? Integer.parseInt(field.trim()) : null;
	}
}

class FileEntity {
	Date resultTime;
	int granularityPeriod;
	String objectName;
	int cellsId;
	int cellAttempt;

	public Date getResultTime() {
		return resultTime;
	}

	public void setResultTime(Date resultTime) {
		this.resultTime = resultTime;
	}

	public int getGranularityPeriod() {
		return granularityPeriod;
	}

	public void setGranularityPeriod(int granularityPeriod) {
		this.granularityPeriod = granularityPeriod;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public int getCellsId() {
		return cellsId;
	}

	public void setCellsId(int cellsId) {
		this.cellsId = cellsId;
	}

	public int getCellAttempt() {
		return cellAttempt;
	}

	public void setCellAttempt(int cellAttempt) {
		this.cellAttempt = cellAttempt;
	}
}
