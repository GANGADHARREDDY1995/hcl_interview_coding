package lambdaExpression;

public class BinaryTreeTravarsal {

	public static void main(String[] args) {

		BinaryTree tree = new BinaryTree();
		tree.root = new Node(1);

		tree.root.right = new Node(2);
		tree.root.right.right = new Node(5);

		tree.root.right.right.left = new Node(3);
		tree.root.right.right.right = new Node(6);

		tree.root.right.right.left.right = new Node(4);

		System.out.println("Preorder traversal of binary tree is ");
		tree.print(tree.root);

	}
}

class Node {
	int key;
	Node left, right;

	public Node(int value) {
		this.key = value;
		left = null;
		right = null;
	}

}

class BinaryTree {

	Node root;

	public BinaryTree() {
	}

	public void print(Node node) {
		if (node == null)
			return;
		System.out.print(node.key + " ");

		print(node.left);
		print(node.right);

	}

}
